from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
X = np.array([[1,2],[2,4],[1.5,0],
[10,2],[8,8],[9,1]])
kmeans = KMeans(n_clusters=2, n_init=10).fit(X)
print("Cluster Labels:", kmeans.labels_)
print("Cluster Centers:\n", kmeans.cluster_centers_)
plt.scatter(X[:,0], X[:,1], c=kmeans.labels_, cmap='rainbow')
plt.scatter(kmeans.cluster_centers_[:,0], kmeans.cluster_centers_[:1],
c='black', marker='x')
plt.show()
