from itertools import combinations

T = [
    ['A','B','C','D'],
    ['A','C','D'],
    ['B','C','E'],
    ['A','B','C','E'],
    ['B','C','D'],
    ['A','B','C'],
    ['A','C','E'],
    ['B','C','D','E']
]
min_sup_count = 0.5 * len(T)  # min support as count

def get_support_count(itemset):
    count = 0
    for transaction in T:
        if set(itemset).issubset(transaction):
            count += 1
    return count

def apriori():
    # Get frequent 1-itemsets
    items = sorted(list({item for transaction in T for item in transaction}))
    L1 = []
    for item in items:
        sup_count = get_support_count([item])
        if sup_count >= min_sup_count:
            L1.append(([item], sup_count))
    
    frequent_itemsets = L1.copy()
    L_prev = [itemset for itemset, _ in L1]
    
    k = 2
    while L_prev:
        # Generate candidates
        C_k = []
        for i in range(len(L_prev)):
            for j in range(i+1, len(L_prev)):
                # Join step
                if L_prev[i][:-1] == L_prev[j][:-1]:
                    candidate = sorted(list(set(L_prev[i]) | set(L_prev[j])))
                    if len(candidate) == k and candidate not in C_k:
                        C_k.append(candidate)
        
        # Prune step (check if all subsets are frequent)
        C_k_pruned = []
        for candidate in C_k:
            # Generate all (k-1)-subsets
            all_subsets_frequent = True
            for subset in combinations(candidate, k-1):
                if list(subset) not in L_prev:
                    all_subsets_frequent = False
                    break
            if all_subsets_frequent:
                C_k_pruned.append(candidate)
        
        # Calculate support and find frequent itemsets
        L_k = []
        for candidate in C_k_pruned:
            sup_count = get_support_count(candidate)
            if sup_count >= min_sup_count:
                L_k.append((candidate, sup_count))
        
        frequent_itemsets.extend(L_k)
        L_prev = [itemset for itemset, _ in L_k]
        k += 1
    
    return frequent_itemsets

# Run Apriori
frequent_itemsets = apriori()

print("Frequent Itemsets with Support Count:")
for itemset, sup_count in frequent_itemsets:
    print(f"{itemset} -> {sup_count/len(T):.3f} ({sup_count})")