from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import matplotlib.pyplot as plt
X = [
[0, 0], [1, 1], [1, 0], [0, 1],
[2, 1], [2, 0], [3, 3], [3, 2],
[4, 4], [4, 3]
]
y = [0, 1, 1, 0, 1, 0, 1, 1, 1, 1]
clf = DecisionTreeClassifier()
clf.fit(X, y)
predictions = clf.predict([[1, 0], [3, 3], [0, 0]])
print("Predictions:", predictions)
tree.plot_tree(clf)
plt.show()
