import pandas as pd

# Sample dataset
data = {'Age': [25, 30, 45, 35, 22],
        'Salary': [50000, 60000, 80000, 75000, 40000],
        'Department': ['HR', 'IT', 'Finance', 'IT', 'HR']}

df = pd.DataFrame(data)
print("Original Data:\n", df)

# Handling missing values (example)
df.fillna(df.mean(numeric_only=True), inplace=True)

# Normalization
df['Salary_Norm'] = (df['Salary'] - df['Salary'].min()) / (df['Salary'].max() - df['Salary'].min())

# One-Hot Encoding
df = pd.get_dummies(df, columns=['Department'])

print("\nPreprocessed Data:\n", df)
