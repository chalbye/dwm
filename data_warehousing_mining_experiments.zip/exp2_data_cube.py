import pandas as pd

data = {'Product': ['A', 'A', 'B', 'B', 'C'],
        'Region': ['East', 'West', 'East', 'West', 'East'],
        'Sales': [100, 150, 200, 250, 300]}

df = pd.DataFrame(data)

# Data cube (group by multiple dimensions)
cube = df.groupby(['Product', 'Region']).sum().reset_index()
print("Data Cube:\n", cube)
