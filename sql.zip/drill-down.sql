-- Create Product Dimension Table
CREATE TABLE dim_product (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    category VARCHAR(50)
);

-- Create Date Dimension Table
CREATE TABLE dim_date (
    date_id INT PRIMARY KEY,
    year INT,
    month INT,
    day INT
);

-- Create Fact Table
CREATE TABLE fact_sales (
    sale_id INT PRIMARY KEY,
    date_id INT,
    product_id INT,
    amount INT,
    FOREIGN KEY (date_id) REFERENCES dim_date(date_id),
    FOREIGN KEY (product_id) REFERENCES dim_product(product_id)
);

-- Insert into dim_product
INSERT INTO dim_product VALUES
(1, 'Shoe', 'Footwear'),
(2, 'Bag',  'Accessories'),
(3, 'Watch','Accessories');

-- Insert into dim_date
INSERT INTO dim_date VALUES
(101, 2025, 3, 10),
(102, 2025, 3, 12),
(103, 2025, 4, 5),
(104, 2025, 4, 15),
(105, 2025, 5, 20);

-- Insert into fact_sales
INSERT INTO fact_sales VALUES
(1, 101, 1, 500),
(2, 102, 1, 700),
(3, 103, 2, 300),
(4, 104, 3, 200),
(5, 105, 1, 450);


-- Monthly sales for 2025
SELECT d.month, SUM(f.amount) AS monthly_sales
FROM fact_sales f
JOIN dim_date d ON f.date_id = d.date_id
WHERE d.year = 2025
GROUP BY d.month;